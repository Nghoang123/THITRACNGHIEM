UNITY 6 / WINDOWS / URP — HƯỚNG DẪN NHẬP VÀ KIỂM TRA
Tình trạng: hướng dẫn chưa chạy trong Unity Editor. Đây là prototype.

1. Giải nén BadmintonAthlete_Package.zip trên Windows. Giữ toàn bộ Textures.
2. Trong project Unity 6, tạo Assets/Badminton/Characters/Athlete.
   Copy Models và Textures vào đó. Không cần đưa thư mục Blender vào Assets.
3. Chọn LeeChongWei_Athlete.fbx > Inspector > Model:
   bật Convert Units nếu có, Scale Factor=1 trước khi đo trong Scene.
   Kiểm tra cao khoảng 1.75m. Không sửa scale rig tùy tiện để bù sai đơn vị.
4. Rig > Animation Type=Humanoid > Avatar Definition=Create From This Model > Apply.
   Nhấn Configure. Nếu auto-map thiếu xương, gán theo tên:
   Hips; Spine; Chest; UpperChest; Neck; Head;
   Left/RightShoulder, UpperArm, LowerArm, Hand;
   Left/RightUpperLeg, LowerLeg, Foot, Toes.
   Ngón tay: Left/Right + Thumb/Index/Middle/Ring/Little + Proximal/Intermediate/Distal.
   Unity gọi Little là Little Finger ở một số giao diện. Không map nhầm finger sang Hand.
   Nếu Configure chưa màu xanh, chưa được xem là Avatar hợp lệ.
5. Pose > Enforce T-Pose (nguồn là A-pose). Kiểm tra vai, khuỷu tay, gối đúng chiều.
   Apply > Done. Avatar validation này chưa được thực hiện trong môi trường Cloud.
6. Materials: FBX có texture nhúng, nhưng shader Blender không chuyển nguyên vẹn sang URP.
   Dùng Extract Textures/Extract Materials nếu Unity cung cấp, hoặc gán PNG ngoài.
   Tạo URP/Lit material tương ứng tên trong FBX:
   Skin -> Body/Skin_*; Face -> Face/Face_*; Eyes_Brown -> Face/Eyes_Brown_BaseColor;
   Hair -> Hair/Hair_*; Jersey_Red/Shorts_Crimson/Sock -> Clothes/*;
   Shoe_White -> Shoes/Shoe_White_*; Racket_Carbon -> Racket/Racket_Carbon_*.
   Các material trim, cao su, dây vợt và grip là màu scalar trong FBX.
   BaseColor: sRGB bật. Roughness: sRGB tắt. Normal: Texture Type=Normal map.
   URP/Lit không có cổng Roughness: Smoothness = 1 - Roughness.
   Có thể dùng scalar trung bình: Skin .47; Face .50; Jersey .36; Shorts .34;
   Hair .53; Shoe .42; Racket .72. Muốn giữ map: đóng gói 1-Roughness vào
   alpha MetallicGlossMap, RGB đen vì metallic=0, chọn Smoothness Source thích hợp.
   Kiểm tra hướng normal dưới đèn trước khi đảo green channel, không tự động đảo.
7. Tạo GameObject Player_Athlete, kéo FBX thành child. Thêm Animator ở model root
   có Avatar đã xác nhận. Thêm CharacterController và movement ở Player root.
   Save thành prefab Assets/Badminton/Characters/Player_Athlete.prefab.
8. Kéo Badminton_Racket.fbx vào Scene, tạo RightHandRacketSocket dưới RightHand.
   Reparent racket vào socket, chỉnh Position/Rotation theo bàn tay trong Scene view.
   Pivot FBX ở đuôi grip; +Z dọc cán; X ngang mặt vợt; Y pháp tuyến mặt vợt.
   Cần cuộn các ngón quanh grip trong animation hoặc dùng Animation Rigging.
   Chưa có socket offset chuẩn cho mọi retarget; BLEND chỉ là gợi ý vị trí.
9. Gắn Animator Controller hiện có. Các clip cầu lông phải có Humanoid Avatar hợp lệ.
   Với clip cùng skeleton: Rig > Copy From Other Avatar, chọn avatar nhân vật.
   Với clip skeleton khác: tạo Avatar của clip đó trước; Unity sẽ retarget Humanoid.
   Kiểm tra root motion, Foot IK và Apply Root Motion theo movement controller.
10. Deformation_Tests.fbx là bộ stress test Generic, gồm Test_Knee_Lunge,
    Test_Overhead, Test_Elbow. Nguồn xoay xương cơ bản, không dùng thay animation
    Ready Stance, Smash hoặc Lunge chuẩn. Import Generic để quan sát đúng xương.
    Nếu chuyển các clip này sang Humanoid, cần kiểm tra riêng kết quả retarget.
11. Badminton Studio: không có project/API trong phiên này nên không có tích hợp
    tự động. Thay model child của player bằng prefab, nối trường Animator/Avatar
    và racket socket vào script hiện có. Giữ component movement, collider,
    input, network identity của player theo kiến trúc project của bạn.
12. Play Ready Stance hiện có, sau đó chạy 8 hướng, lunge và overhead/smash.
    Quan sát vai không sụp, khuỷu/gối đúng chiều, chân không xoắn, hông không kéo
    quần bất thường, grip không trượt và dây vợt không đảo mặt. Kiểm tra da lộ ở
    biên áo/quần, giày/tất, rồi sửa weight hoặc topology trong BLEND khi cần.
    Chưa có kết quả Play Mode hoặc retarget Unity được xác minh cho gói này.
