import bpy, math, json, pathlib, numpy as np, bmesh, shutil
from mathutils import Vector
from mathutils.kdtree import KDTree
P=pathlib.Path('/workspace/outputs/BadmintonAthlete_Package'); W=pathlib.Path('/workspace/work')
for d in ['Models','Blender','Textures/Body','Textures/Face','Textures/Hair','Textures/Clothes','Textures/Shoes','Textures/Racket','Unity','Previews','Validation','Sources']:(P/d).mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
# Preserve original topology, UV coordinates and authored weights from CC0 MakeHuman.
v=[];uv=[];faces=[];fuv=[];grp='';groups=[]
for l in open(W/'base.obj'):
 q=l.split()
 if not q:continue
 if q[0]=='v':v.append(list(map(float,q[1:4])))
 elif q[0]=='vt':uv.append(list(map(float,q[1:3])))
 elif q[0]=='g':grp=q[1]
 elif q[0]=='f' and grp=='body':
  faces.append([int(x.split('/')[0])-1 for x in q[1:]]);fuv.append([int(x.split('/')[1])-1 for x in q[1:]])
v=np.array(v);original=v.copy()
for t,factor in [('asian-male-young.target',1),('athletic.target',0.75)]:
 for l in open(W/t):
  q=l.split()
  if not q or q[0].startswith('#'):continue
  v[int(q[0])]+=np.array(list(map(float,q[1:4])))*factor
used=sorted({i for f in faces for i in f}); ground=v[used,1].min();top=v[used,1].max();S=1.74/(top-ground)
coords=np.stack([v[:,0]*S,-v[:,2]*S,(v[:,1]-ground)*S],axis=1)
# Shift to sole ground clearance. Body height 1.74m plus 18mm soles.
coords[:,2]+=.018
rigsrc=json.load(open(W/'default.mhskel')); sw=json.load(open(W/'default_weights.mhw'))['weights']
def joint(key):return Vector(coords[rigsrc['joints'][key]].mean(axis=0))
def j(n,end='head'):return joint(rigsrc['bones'][n][end])
# Collapse twist/facial helper weights into a 55-bone Unity-named hierarchy.
mapn={}; defs={}
def bone(name,head,tail,parent,sources):
 defs[name]=(head,tail,parent)
 for s in sources:mapn[s]=name
bone('Hips',j('upperleg01.L').lerp(j('upperleg01.R'),.5),j('spine05'),None,['root','pelvis.L','pelvis.R'])
bone('Spine',j('spine05'),j('spine03'),'Hips',['spine05','spine04'])
bone('Chest',j('spine03'),j('spine01'),'Spine',['spine03','spine02','breast.L','breast.R'])
bone('UpperChest',j('spine01'),j('neck01'),'Chest',['spine01'])
bone('Neck',j('neck01'),j('head'),'UpperChest',['neck01','neck02','neck03'])
bone('Head',j('head'),j('head','tail'),'Neck',['head'])
for side,word in [('L','Left'),('R','Right')]:
 suff='.'+side
 bone(word+'Shoulder',j('clavicle'+suff),j('upperarm01'+suff),'UpperChest',['clavicle'+suff,'shoulder01'+suff])
 bone(word+'UpperArm',j('upperarm01'+suff),j('lowerarm01'+suff),word+'Shoulder',['upperarm01'+suff,'upperarm02'+suff])
 bone(word+'LowerArm',j('lowerarm01'+suff),j('wrist'+suff),word+'UpperArm',['lowerarm01'+suff,'lowerarm02'+suff])
 bone(word+'Hand',j('wrist'+suff),j('wrist'+suff,'tail'),word+'LowerArm',['wrist'+suff]+['metacarpal'+str(i)+suff for i in range(1,5)])
 bone(word+'UpperLeg',j('upperleg01'+suff),j('lowerleg01'+suff),'Hips',['upperleg01'+suff,'upperleg02'+suff])
 bone(word+'LowerLeg',j('lowerleg01'+suff),j('foot'+suff),word+'UpperLeg',['lowerleg01'+suff,'lowerleg02'+suff])
 bone(word+'Foot',j('foot'+suff),j('toe3-1'+suff),word+'LowerLeg',['foot'+suff])
 bone(word+'Toes',j('toe3-1'+suff),j('toe3-3'+suff,'tail'),word+'Foot',[k for k in sw if k.startswith('toe') and k.endswith(suff)])
 for fi,fn in enumerate(['Thumb','Index','Middle','Ring','Little'],1):
  for seg,sn in enumerate(['Proximal','Intermediate','Distal'],1):
   source=f'finger{fi}-{seg}{suff}';name=word+fn+sn
   bone(name,j(source),j(source,'tail'),word+'Hand' if seg==1 else word+fn+['Proximal','Intermediate'][seg-2],[source])
for k in sw:
 if k not in mapn:mapn[k]='Head'
weights=[{} for _ in v]
for src,entries in sw.items():
 for i,w in entries:
  if i<len(v):weights[i][mapn[src]]=weights[i].get(mapn[src],0)+w
for i in used:
 a=sorted(weights[i].items(),key=lambda x:-x[1])[:4];total=sum(w for _,w in a)
 weights[i]={n:w/total for n,w in a} if total else {'Hips':1}
armdata=bpy.data.armatures.new('Athlete_Humanoid');arm=bpy.data.objects.new('Athlete_Rig',armdata);bpy.context.collection.objects.link(arm);bpy.context.view_layer.objects.active=arm;arm.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
for n,(h,t,parent) in defs.items():
 b=armdata.edit_bones.new(n);b.head=h;b.tail=t
 if (t-h).length<.001:b.tail=h+Vector((0,0,.01))
 b.align_roll(Vector((0,-1,0)))
for n,(_,_,parent) in defs.items():
 if parent:armdata.edit_bones[n].parent=armdata.edit_bones[parent]
bpy.ops.object.mode_set(mode='OBJECT');arm.show_in_front=True
# Authored raster maps, intentionally modest procedural detail, no photographic skin claims.
rng=np.random.default_rng(23)
def tex(name,folder,col,kind='skin',rough=.5,N=512):
 y,x=np.mgrid[:N,:N];noise=rng.normal(0,1,(N,N));micro=np.sin(x*2.4)*np.sin(y*2.6)
 if kind=='cloth':pat=(np.sin(x*1.8)*np.cos(y*1.8))*.017+noise*.006
 elif kind=='hair':pat=np.sin(x*.8+np.sin(y*.016)*3)*.045+noise*.008
 else:pat=noise*.009+np.sin(x*.045)*np.cos(y*.038)*.007
 def save(suffix,a,color='sRGB'):
  im=bpy.data.images.new(name+'_'+suffix,width=N,height=N,alpha=True);im.colorspace_settings.name=color
  if a.ndim==2:a=np.repeat(a[:,:,None],3,axis=2)
  rgba=np.concatenate([a,np.ones((N,N,1))],axis=2).astype(np.float32);im.pixels.foreach_set(rgba.ravel());im.filepath_raw=str(P/'Textures'/folder/(name+'_'+suffix+'.png'));im.file_format='PNG';im.save();return im
 base=np.clip(np.array(col)[None,None,:]+pat[:,:,None],0,1);bi=save('BaseColor',base)
 ri=save('Roughness',np.clip(rough+pat*.8,0,1),'Non-Color')
 # Tangent normal from a small analytic microstructure, not a high-poly bake.
 nx=(np.cos(x*1.8)*np.sin(y*1.8))*(.035 if kind=='cloth' else .012);ny=(np.sin(x*1.8)*np.cos(y*1.8))*(.035 if kind=='cloth' else .012)
 ni=save('Normal',np.stack([.5+nx,.5+ny,np.sqrt(np.maximum(0,1-4*nx*nx-4*ny*ny))*.5+.5],axis=2),'Non-Color')
 mat=bpy.data.materials.new(name);mat.use_nodes=True;nodes=mat.node_tree.nodes;links=mat.node_tree.links;bs=nodes.get('Principled BSDF')
 for im,socket in [(bi,'Base Color'),(ri,'Roughness')]:
  node=nodes.new('ShaderNodeTexImage');node.image=im;links.new(node.outputs['Color'],bs.inputs[socket])
 tn=nodes.new('ShaderNodeTexImage');tn.image=ni;nm=nodes.new('ShaderNodeNormalMap');links.new(tn.outputs['Color'],nm.inputs['Color']);links.new(nm.outputs['Normal'],bs.inputs['Normal']);bs.inputs['Subsurface Weight'].default_value=.06 if kind=='skin' else 0
 return mat
skin=tex('Skin','Body',(.61,.37,.235),rough=.53);faceMat=tex('Face','Face',(.62,.385,.25),rough=.5)
red=tex('Jersey_Red','Clothes',(.59,.012,.03),'cloth',.64);shortmat=tex('Shorts_Crimson','Clothes',(.36,.008,.019),'cloth',.66)
hairmat=tex('Hair','Hair',(.023,.018,.014),'hair',.47);white=tex('Shoe_White','Shoes',(.77,.80,.79),'cloth',.58);sockmat=tex('Sock','Clothes',(.79,.81,.8),'cloth',.7)
racketmat=tex('Racket_Carbon','Racket',(.024,.035,.046),'cloth',.28)
def flat(name,col,rough=.5,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*col,1);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*col,1);b.inputs['Roughness'].default_value=rough;b.inputs['Metallic'].default_value=metal;return m
accent=flat('Warm_Ivory_Trim',(.87,.66,.28));solemat=flat('Rubber_Sole',(.11,.14,.14),.8);gripmat=flat('Grip_Gold',(.76,.82,.12),.8);stringmat=flat('String_Ivory',(.74,.77,.7),.35)
# Source-normal offsets for clothing, with smoothing to suppress anatomical detail.
def mesh_obj(name,verts,fs,mat,uvs=None):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],fs);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob);ob.data.materials.append(mat)
 bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(me);bm.free()
 if uvs:
  layer=me.uv_layers.new(name='UVMap')
  for poly,uvf in zip(me.polygons,uvs):
   for li,uvv in zip(poly.loop_indices,uvf):layer.data[li].uv=uvv
 else:
  bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(island_margin=.015);bpy.ops.object.mode_set(mode='OBJECT')
 for p in me.polygons:p.use_smooth=True
 return ob
def bind(ob,ids=None,rigid=None):
 for n in defs:ob.vertex_groups.new(name=n)
 for i in range(len(ob.data.vertices)):
  ww={rigid:1} if rigid else weights[ids[i]]
  for n,w in ww.items():ob.vertex_groups[n].add([i],w,'REPLACE')
 mod=ob.modifiers.new('Humanoid_Skin','ARMATURE');mod.object=arm;ob.parent=arm
 return ob
alluv=[[uv[k] for k in f] for f in fuv]
# Create full body first to obtain smooth normals.
idmap={old:i for i,old in enumerate(used)}
body=mesh_obj('Body',coords[used].tolist(),[[idmap[i] for i in f] for f in faces],skin,alluv);bind(body,used)
body.data.materials.append(faceMat)
for poly in body.data.polygons:
 if poly.center.z>1.5:poly.material_index=1
normals={old:body.data.vertices[idx].normal.copy() for old,idx in idmap.items()}
centers=np.array([coords[f].mean(axis=0) for f in faces])
shirtmask=[1.035<c[2]<1.49 and abs(c[0])<.229 and not(c[2]>1.455 and abs(c[0])<.069) for c in centers]
shortmask=[.665<c[2]<1.075 and abs(c[0])<.29 for c in centers]
sockmask=[.105<c[2]<.245 for c in centers]
shoemask=[c[2]<.12 for c in centers]
def garment(name,mask,material,offset,smooth=0):
 fi=[i for i,b in enumerate(mask) if b];inds=sorted({k for i in fi for k in faces[i]});im={old:i for i,old in enumerate(inds)}
 vv=[Vector(coords[i])+normals[i]*offset for i in inds];fs=[[im[k] for k in faces[i]] for i in fi]
 ob=mesh_obj(name,vv,fs,material,[alluv[i] for i in fi]);bind(ob,inds)
 if smooth:
  mod=ob.modifiers.new('Tailored_surface','SMOOTH');mod.factor=.8;mod.iterations=smooth
  bpy.context.view_layer.objects.active=ob;bpy.ops.object.modifier_move_up(modifier=mod.name);bpy.ops.object.modifier_apply(modifier=mod.name)
 mod=ob.modifiers.new('Fabric_Thickness','SOLIDIFY');mod.thickness=.0018;mod.offset=0
 return ob
shirt=garment('Sleeveless_Jersey',shirtmask,red,.009,3);shorts=garment('Sport_Shorts',shortmask,shortmat,.019,9);socks=garment('Crew_Socks',sockmask,sockmat,.004,2);shoes=garment('Court_Shoes',shoemask,white,.013,16)
# Remove hidden body polygons only after garment derivation; retain complete original in Sources.
hide=[a or b or c or d for a,b,c,d in zip(shirtmask,shortmask,sockmask,shoemask)]
# Preserve skin under two boundary rings so garment offset does not expose holes.
edgefaces={}
for fi,f in enumerate(faces):
 for a,b in zip(f,f[1:]+f[:1]):edgefaces.setdefault(tuple(sorted((a,b))),[]).append(fi)
for _ in range(2):
 expose=set()
 for ff in edgefaces.values():
  if len(ff)==2 and hide[ff[0]]!=hide[ff[1]]:expose.update(ff)
 hide=[h and i not in expose for i,h in enumerate(hide)]
bm=bmesh.new();bm.from_mesh(body.data);bm.faces.ensure_lookup_table();bmesh.ops.delete(bm,geom=[bm.faces[i] for i,b in enumerate(hide) if b],context='FACES');bm.to_mesh(body.data);bm.free()
# Hair cap follows the skull; no primitive head substitution.
hairmask=[]
for c in centers:
 # front is -Y, sport taper with a higher forehead line.
 threshold=1.662 if c[1]<-.035 else 1.62
 hairmask.append(c[2]>threshold)
hair=garment('Short_Sport_Hair',hairmask,hairmat,.004,2)
# Curve meshes for seams, laces, brows and racket string bed.
def tube(name,points,radius,mat,cyclic=False,rigid=None):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=2;cu.bevel_depth=radius;cu.bevel_resolution=2;spl=cu.splines.new('POLY');spl.points.add(len(points)-1)
 for p,co in zip(spl.points,points):p.co=(*co,1)
 spl.use_cyclic_u=cyclic;ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob);ob.data.materials.append(mat)
 bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH')
 if rigid:bind(ob,rigid=rigid)
 return ob
# Borders from extracted jersey mesh (all open boundary loops), transfer nearest body weights.
def edge_trim(ob):
 bm=bmesh.new();bm.from_mesh(ob.data);edges=[e for e in bm.edges if e.is_boundary];pairs=[(e.verts[0].co.copy(),e.verts[1].co.copy()) for e in edges];bm.free()
 trim=[]
 for a,b in pairs:trim.append(tube('Jersey_Edge', [a,b],.0015,accent))
 bpy.ops.object.select_all(action='DESELECT')
 for o in trim:o.select_set(True)
 bpy.context.view_layer.objects.active=trim[0];bpy.ops.object.join();o=bpy.context.object;o.name='Jersey_Binding'
 kd=KDTree(len(used))
 for k,i in enumerate(used):kd.insert(coords[i],i)
 kd.balance();bind(o,[kd.find(v.co)[1] for v in o.data.vertices])
edge_trim(shirt)
# Eye meshes from CC0 source; deform by nearest base displacement.
eyv=[];eyf=[];eyuv=[];euv=[]
for l in open(W/'low-poly.obj'):
 q=l.split()
 if not q:continue
 if q[0]=='v':eyv.append(list(map(float,q[1:4])))
 elif q[0]=='vt':euv.append(tuple(map(float,q[1:3])))
 elif q[0]=='f':eyf.append([int(t.split('/')[0])-1 for t in q[1:]]);eyuv.append([euv[int(t.split('/')[1])-1] for t in q[1:]])
# Eye displacement calculated from nearest original body vertices.
kd=KDTree(len(used))
for i in used:kd.insert(original[i],i)
kd.balance();ev=[]
for co in eyv:
 _,idx,_=kd.find(co);a=np.array(co)+(v[idx]-original[idx]);ev.append((a[0]*S,-a[2]*S,(a[1]-ground)*S+.018))
eye=flat('Eyes_Brown',(1,1,1),.25);im=bpy.data.images.load(str(W/'brown_eye.png'));shutil.copy(W/'brown_eye.png',P/'Textures/Face/Eyes_Brown_BaseColor.png');im.filepath=str(P/'Textures/Face/Eyes_Brown_BaseColor.png');node=eye.node_tree.nodes.new('ShaderNodeTexImage');node.image=im;eye.node_tree.links.new(node.outputs['Color'],eye.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
bind(mesh_obj('Eyes',ev,eyf,eye,eyuv),rigid='Head')
# Soles follow foot centers, with a shaped planform and separate rubber geometry.
for side,word in [('L','Left'),('R','Right')]:
 h=j('foot.'+side);cx=h.x
 verts=[];N=40
 for z,expand in [(.005,1),(.033,1.03),(.048,.95)]:
  for k in range(N):
   a=2*math.pi*k/N;verts.append((cx+math.cos(a)*.054*expand,h.y-.041+math.sin(a)*.133*expand,z))
 fs=[]
 for r in range(2):
  for k in range(N):fs.append((r*N+k,r*N+(k+1)%N,(r+1)*N+(k+1)%N,(r+1)*N+k))
 fs += [tuple(reversed(range(N))),tuple(range(2*N,3*N))]
 bind(mesh_obj(word+'_Sole',verts,fs,solemat),rigid=word+'Foot')
 for k in range(4):
  yy=h.y-.035-k*.013;zz=.115-k*.012
  tube(word+'_Lace_'+str(k),[(cx-.027,yy,zz),(cx,yy-.008,zz+.008),(cx+.027,yy,zz)],.0016,sockmat,rigid=word+'Foot')
# Racket local axes: +Z shaft/head, X string width, Y bed normal. Grip origin at butt.
rack=[]
def rt(name,pts,r,mat,closed=False):
 ob=tube(name,pts,r,mat,closed);rack.append(ob);return ob
rt('Racket_Grip',[(0,0,0),(0,0,.16)],.014,gripmat)
rt('Racket_Shaft',[(0,0,.16),(0,0,.42)],.0033,racketmat)
rt('Racket_Frame',[(.119*math.cos(a),0,.535+.151*math.sin(a)) for a in np.linspace(0,2*math.pi,100,endpoint=False)],.004,racketmat,True)
for x in np.arange(-.105,.106,.009):
 hh=.151*math.sqrt(1-(x/.119)**2);rt('String_V',[(x,0,.535-hh),(x,0,.535+hh)],.00042,stringmat)
for z in np.arange(-.135,.136,.009):
 ww=.119*math.sqrt(1-(z/.151)**2);rt('String_H',[(-ww,0,.535+z),(ww,0,.535+z)],.00042,stringmat)
for z in np.arange(.01,.16,.009):rt('Grip_Wrap',[ (.0142*math.cos(a),.0142*math.sin(a),z+.008*a/(2*math.pi)) for a in np.linspace(0,2*math.pi,24)],.00065,solemat)
bpy.ops.object.select_all(action='DESELECT')
for o in rack:o.select_set(True)
bpy.context.view_layer.objects.active=rack[0];bpy.ops.object.join();racket=bpy.context.object;racket.name='Badminton_Racket'
# Apply transforms to get grip-butt pivot (mesh currently world origin).
bpy.context.scene.cursor.location=(0,0,0);bpy.ops.object.origin_set(type='ORIGIN_CURSOR');bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
def export(path,objects,anim=False):
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0]
 bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'ARMATURE','MESH','EMPTY'},axis_forward='-Z',axis_up='Y',apply_unit_scale=True,apply_scale_options='FBX_SCALE_UNITS',use_mesh_modifiers=True,add_leaf_bones=False,primary_bone_axis='Y',secondary_bone_axis='X',bake_anim=anim,bake_anim_use_all_actions=False,bake_anim_use_nla_strips=anim,bake_anim_force_startend_keying=True,path_mode='COPY',embed_textures=True)
export(P/'Models/Badminton_Racket.fbx',[racket])
# Bone parent with explicit world matrix. Socket at approximate palm; fingers remain open in A-pose.
hand=arm.data.bones['RightHand'];palm=hand.head_local.lerp(hand.tail_local,.7)
racket.location=palm+Vector((0,-.01,-.07));racket.rotation_euler=(0,math.radians(-34),0)
bpy.context.view_layer.update();world=racket.matrix_world.copy();racket.parent=arm;racket.parent_type='BONE';racket.parent_bone='RightHand';bpy.context.view_layer.update();racket.matrix_world=world
racket['Grip_Status']='Approximate palm attachment; author grip finger pose in Unity. Standalone FBX pivot at butt.'
# Numerical pose stress clips: A-rest -> deformation challenge -> A-rest. These are not sports motion capture.
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1;scene.render.fps=30
pose_specs={
 'Test_Knee_Lunge':{'RightUpperLeg':(math.radians(-48),0,0),'RightLowerLeg':(math.radians(78),0,0),'LeftUpperLeg':(math.radians(20),0,0),'Spine':(math.radians(12),0,0)},
 'Test_Overhead':{'RightUpperArm':(0,0,math.radians(-105)),'RightLowerArm':(math.radians(-60),0,0),'Chest':(0,math.radians(12),0)},
 'Test_Elbow':{'RightLowerArm':(math.radians(-80),0,0),'LeftLowerArm':(math.radians(-65),0,0)}}
for name,spec in pose_specs.items():
 act=bpy.data.actions.new(name);arm.animation_data_create();arm.animation_data.action=act
 for frame in [1,16,31]:
  scene.frame_set(frame)
  for pb in arm.pose.bones:
   pb.rotation_mode='XYZ';pb.rotation_euler=spec.get(pb.name,(0,0,0)) if frame==16 else (0,0,0);pb.keyframe_insert('rotation_euler',frame=frame,group=pb.name)
 tr=arm.animation_data.nla_tracks.new();tr.name=name;st=tr.strips.new(name,1,act);tr.mute=True
arm.animation_data.action=None
for pb in arm.pose.bones:pb.rotation_euler=(0,0,0)
scene.frame_set(1)
characters=[o for o in scene.objects if o.type=='MESH' and o!=racket]
export(P/'Models/LeeChongWei_Athlete.fbx',[arm]+characters,False)
# Optional separate generic rig pose clips; leave main model in rest pose.
for tr in arm.animation_data.nla_tracks:tr.mute=False
export(P/'Models/Deformation_Tests.fbx',[arm]+characters,True)
for tr in arm.animation_data.nla_tracks:tr.mute=True
# Studio previews, not exported.
floor=flat('StudioFloor',(.033,.052,.057),.75)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,0));groundob=bpy.context.object;groundob.name='Studio_Ground';groundob.data.materials.append(floor)
world=bpy.data.worlds.new('Studio') if not scene.world else scene.world;scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.065,.08,.1,1);world.node_tree.nodes['Background'].inputs[1].default_value=.45
def area(name,loc,power,size):
 data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;o=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,1))-o.location).to_track_quat('-Z','Y').to_euler()
area('Key',(2,-3,4),450,3);area('Fill',(-2,-1,2.2),200,2);area('Rim',(0,2,3),500,2)
camdata=bpy.data.cameras.new('Preview');cam=bpy.data.objects.new('Preview',camdata);bpy.context.collection.objects.link(cam);scene.camera=cam;camdata.type='ORTHO';camdata.ortho_scale=2.23
scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False;scene.render.resolution_x=900;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX'
for name,loc in [('Front',(0,-4,1.0)),('Side',(4,0,1.0)),('Back',(0,4,1.0)),('ThreeQuarter',(2.4,-4,1.5))]:
 cam.location=loc;cam.rotation_euler=(Vector((0,0,.9))-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(P/'Previews'/(name+'.png'));bpy.ops.render.render(write_still=True)
# Pack images and preserve relative external paths too.
for im in bpy.data.images:
 if im.source=='FILE':
  im.pack()
  try:im.filepath='//'+str(pathlib.Path(im.filepath).relative_to(P/'Blender'))
  except:im.filepath='//../Textures/'+str(pathlib.Path(im.filepath).relative_to(P/'Textures')) if str(im.filepath).startswith(str(P/'Textures')) else im.filepath
bpy.ops.wm.save_as_mainfile(filepath=str(P/'Blender/LeeChongWei_Athlete.blend'))
report={'blender':bpy.app.version_string,'body_height_m':1.74,'bone_count':len(defs),'bone_names':list(defs),'source_body_faces':len(faces),'source_body_vertices':len(used),'meshes':{o.name:{'vertices':len(o.data.vertices),'triangles':sum(len(f.vertices)-2 for f in o.data.polygons)} for o in characters},'rig_mapping':mapn,'limitations':['Approximate generic likeness, no facial scan or artist sculpt likeness validation.','Procedural color/roughness/micro-normal maps; not scanned PBR skin.','Rest A-pose with open fingers; approximate racket palm attachment.','Pose clips are synthetic deformation stress tests, not playable badminton animations.','No Unity Editor, Avatar validation or Badminton Studio integration verified.','Garment extraction and transferred weights need production art review.']}
(P/'Validation/build_report.json').write_text(json.dumps(report,indent=2))
print('BUILD_COMPLETE',json.dumps({'bones':len(defs),'meshes':len(characters),'triangles':sum(x['triangles'] for x in report['meshes'].values())}))
