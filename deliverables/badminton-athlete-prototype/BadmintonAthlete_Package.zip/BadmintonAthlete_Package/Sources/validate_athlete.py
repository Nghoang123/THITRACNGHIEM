import bpy,pathlib,json,math,bmesh,hashlib
from mathutils import Vector
P=pathlib.Path('/workspace/outputs/BadmintonAthlete_Package');out={}
blend=P/'Blender/LeeChongWei_Athlete.blend'
bpy.ops.wm.open_mainfile(filepath=str(blend));arm=bpy.data.objects['Athlete_Rig']
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.name!='Studio_Ground']
images=[{'name':i.name,'packed':bool(i.packed_file),'width':i.size[0],'height':i.size[1]} for i in bpy.data.images if i.name!='Render Result']
checks=[]
for ob in meshes:
 me=ob.data;bad=[]
 for v in me.vertices:
  if not all(math.isfinite(x) for x in v.co):bad.append(v.index)
 degenerate=sum(p.area<1e-12 for p in me.polygons)
 bm=bmesh.new();bm.from_mesh(me);boundary=sum(e.is_boundary for e in bm.edges);wire=sum(e.is_wire for e in bm.edges);bm.free()
 weights=[]
 if any(m.type=='ARMATURE' for m in ob.modifiers):
  for v in me.vertices:
   total=sum(g.weight for g in v.groups)
   if abs(total-1)>.001 or len(v.groups)>4:weights.append(v.index)
 checks.append({'name':ob.name,'vertices':len(me.vertices),'polygons':len(me.polygons),'nonfinite_vertices':bad,'zero_area_faces':degenerate,'boundary_edges':boundary,'wire_edges':wire,'invalid_weights':weights[:20]})
# Verify stress clips actually change evaluated mesh, while recording that finite deformation isn't art validation.
body=bpy.data.objects['Body'];scene=bpy.context.scene;pose=[]
for track in arm.animation_data.nla_tracks:
 for t in arm.animation_data.nla_tracks:t.mute=True
 track.mute=False
 scene.frame_set(1);bpy.context.view_layer.update();d=bpy.context.evaluated_depsgraph_get();ev=body.evaluated_get(d);m=ev.to_mesh();start=[v.co.copy() for v in m.vertices];ev.to_mesh_clear()
 scene.frame_set(16);bpy.context.view_layer.update();ev=body.evaluated_get(d);m=ev.to_mesh();maximum=max((v.co-start[i]).length for i,v in enumerate(m.vertices));finite=all(all(math.isfinite(x) for x in v.co) for v in m.vertices);ev.to_mesh_clear()
 pose.append({'clip':track.name,'max_body_vertex_displacement_m':maximum,'all_coordinates_finite':finite,'artistic_deformation_quality':'NOT certified'})
for t in arm.animation_data.nla_tracks:t.mute=True
scene.frame_set(1)
out['blend_reopened']={'file_bytes':blend.stat().st_size,'bones':len(arm.data.bones),'meshes':checks,'images':images,'pose_evaluation':pose,'racket_bone_parent':bpy.data.objects['Badminton_Racket'].parent_bone}
# Import real FBX in isolated blank scenes. Check binary header as well as Blender parser.
for filename in ['LeeChongWei_Athlete.fbx','Badminton_Racket.fbx','Deformation_Tests.fbx']:
 path=P/'Models'/filename;bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(path))
 obs=list(bpy.context.scene.objects);mm=[o for o in obs if o.type=='MESH'];aa=[o for o in obs if o.type=='ARMATURE']
 bounds=[o.matrix_world@Vector(c) for o in mm for c in o.bound_box]
 out[filename]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'binary_header_valid':path.read_bytes()[:23]==b'Kaydara FBX Binary  \x00\x1a\x00','import_success':True,'mesh_count':len(mm),'vertices':sum(len(o.data.vertices) for o in mm),'triangles':sum(sum(len(p.vertices)-2 for p in o.data.polygons) for o in mm),'armature_count':len(aa),'bone_counts':[len(a.data.bones) for a in aa],'actions':[a.name for a in bpy.data.actions],'world_extent_xyz_m':[max(v[i] for v in bounds)-min(v[i] for v in bounds) for i in range(3)],'missing_uv_meshes':[o.name for o in mm if not o.data.uv_layers]}
 if aa:
  names=set(aa[0].data.bones.keys());expected={'Hips','Spine','Chest','Neck','Head'}|{s+b for s in ['Left','Right'] for b in ['Shoulder','UpperArm','LowerArm','Hand','UpperLeg','LowerLeg','Foot','Toes']};out[filename]['missing_required_bones']=sorted(expected-names)
 if filename=='Deformation_Tests.fbx':assert len(bpy.data.actions)==3,'Expected three imported test actions'
 assert out[filename]['binary_header_valid'] and mm
 if filename!='Badminton_Racket.fbx':assert len(aa)==1 and len(aa[0].data.bones)==52
out['unity_editor_verified']=False;out['self_intersections_or_motion_quality_verified']=False
out['normal_check']='Normals recalculated in Blender; no nonfinite coordinates. No exhaustive orientation/self-intersection proof.'
(P/'Validation/verification.json').write_text(json.dumps(out,indent=2));print('VALIDATION_COMPLETE',json.dumps(out))
