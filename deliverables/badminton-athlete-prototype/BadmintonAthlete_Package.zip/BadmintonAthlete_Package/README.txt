BADMINTON ATHLETE — BẢN PROTOTYPE CÓ RIG / RIGGED PROTOTYPE
Ngày tạo: 2026-11-09. Blender 4.3.2. Đơn vị mét.

ĐÁNH GIÁ TRUNG THỰC
Đây là bản thử nghiệm kỹ thuật từ mesh giải phẫu MakeHuman CC0, không phải
nhân vật chân thực hoàn chỉnh hoặc bản tái tạo chính xác Lee Chong Wei.
Tên LeeChongWei_Athlete được giữ theo cấu trúc tệp được yêu cầu.
Không có scan mặt, điêu khắc chân dung thủ công, tóc hair-card sản xuất,
texture da chụp thực tế hoặc kiểm duyệt chuyên môn về likeness.
Không có Unity Editor hoặc project Badminton Studio trong môi trường này.
Không thể xác nhận Avatar hợp lệ, retarget hoặc tích hợp gameplay thực tế.

CÓ TRONG GÓI
- Mesh giải phẫu người với mặt, tai, mũi, môi, bàn tay và ngón tay có topology.
- Mesh mắt riêng; tóc ngắn dạng scalp cap. Không có facial rig/blendshape.
- Áo sát nách đỏ, short đỏ, tất, giày và đế giày tách riêng; không logo.
- Rig tên xương Unity, A-pose, gồm tay/ngón tay và chân/ngón chân.
- Trọng số gốc MakeHuman được gộp theo xương tương ứng, chuẩn hóa, tối đa 4 ảnh hưởng.
- Vợt riêng có khung oval, cán, grip quấn và lưới dây bằng geometry.
- BLEND có vợt parent vào RightHand ở vị trí lòng bàn tay gần đúng.
- FBX nhân vật không kèm vợt để thay vợt dễ dàng.
- Base Color, Roughness và tangent Normal PNG 512x512 tạo bằng thủ tục.
  Normal chỉ là chi tiết vi mô, không phải bake từ sculpt high-poly.
  Không cần metallic map: dùng scalar Metallic=0; không phải texture PBR cao cấp.
- Ảnh studio chính diện, bên hông, sau lưng và góc 3/4.
- FBX kiểm thử biến dạng bổ sung, không phải bộ animation cầu lông hoàn chỉnh.

GIỚI HẠN CẦN HOÀN THIỆN
1. Khuôn mặt là người nam gần đúng, chưa đạt độ giống ảnh người thật.
2. Áo/quần được lấy từ bề mặt cơ thể và nới ra; cần làm topology trang phục riêng.
3. Một phần da bị che được bỏ để giảm xuyên mesh; mesh nguyên gốc lưu trong Sources.
4. A-pose bàn tay mở; vợt đặt gần tay phải nhưng cần chỉnh grip và cuộn ngón tay.
5. Vai, khuỷu, đầu gối, hông chưa được artist chỉnh corrective shape hoặc weight paint.
6. Clip Test_* là stress test xoay xương, không mô tả chính xác cú đánh thể thao.
7. Cần kiểm tra clipping ở biên áo/quần, đế giày và lace khi chạy/lunge.
8. Chưa có LOD, texture atlas hợp nhất, tối ưu draw calls, facial animation.
9. Chưa xác minh trong Unity 6 Windows, Animator, Animation Rigging hay Badminton Studio.

TRỤC VÀ TỶ LỆ
BLEND: Z up, nhân vật nhìn -Y; cao cơ thể 1.74 m, cộng đế giày.
FBX: export axis_forward=-Z, axis_up=Y, apply_unit_scale=True,
apply_scale_options=FBX_SCALE_UNITS; không thêm leaf bones.
Đừng dựa vào tên trục để khẳng định hướng nhìn trong gameplay:
đo chiều cao và kiểm tra hướng trước sau trong Unity, rồi xoay model child nếu cần.
Model child giữ scale (1,1,1); đặt CharacterController ở root prefab riêng.

MỞ TỆP
Blender/LeeChongWei_Athlete.blend: có mesh, rig, packed texture, studio, camera.
Models/LeeChongWei_Athlete.fbx: mesh nhân vật + skeleton, rest A-pose.
Models/Badminton_Racket.fbx: mesh static, pivot ở đuôi cán, +Z dọc thân vợt.
Models/Deformation_Tests.fbx: mesh + rig với các clip kiểm thử bổ sung.
Trong Blender, bật NLA track từng Test_* để xem; mặc định chúng bị mute.
Sources/build_athlete.py cùng tài nguyên nguồn phục vụ tái tạo và chỉnh sửa.
Validation/ chứa kết quả kiểm tra thực tế; MANIFEST liệt kê chính xác tệp.

Xem Unity/README_Unity_Import.txt để nhập từng bước.
Giấy phép nguồn: Sources/LICENSE.ASSETS.md và Sources/PROVENANCE.txt.
